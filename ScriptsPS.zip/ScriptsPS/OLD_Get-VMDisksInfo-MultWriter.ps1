﻿[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$strClustername
)


#Create the array
$array = @()

$vms = Get-Cluster $strClustername | Get-VM


$report = @()
Write-host "Report Generation is in Progress..."
 
foreach ($vm in $vms  ){
   $view = Get-View $vm
   $disks = Get-AdvancedSetting -Entity $vm |  where{$_.Name -match "^scsi.*sharing"}
   if ($view.config.hardware.Device.Backing.sharing -eq "sharingMultiWriter" -or $disks.value -eq "multi-writer"){

        foreach ($disk in $disks){
            $REPORT = New-Object -TypeName PSObject
            $REPORT | Add-Member -type NoteProperty -name Name -Value $vm.Name
            $REPORT | Add-Member -type NoteProperty -name VMHost -Value $vm.Host
            $REPORT | Add-Member -type NoteProperty -name Mode -Value $disk.Name
            $REPORT | Add-Member -type NoteProperty -name Type -Value "MultiWriter"
            $array += $REPORT
        }

        #$row = '' | select Name
        #$row.Name = $vm.Name

   }
    
}
#$report | Sort Name | Export-Csv -Path "D:\MultiWriter.csv" #Please change the CSV file location
$array
 
Write-host "Report is generated successfully, please check the"



#Create the array

<#
$array = @()
$vms = Get-Cluster $strClustername | Get-VM
foreach ($vm in $vms)
{
    #$disks = Get-AdvancedSetting -Entity $vm | ? { $_.Value -like "*multi-writer*"  }
    $disks = Get-AdvancedSetting -Entity $vm | where{$_.Name -match "^scsi.*sharing"}
    #Get-VM | Select Name, @{ N="Multi-Writer?"; E={ Get-AdvancedSetting -Entity $_ | ? { $_.Value -like "*multi-writer*"  } } }

    foreach ($disk in $disks){
        $REPORT = New-Object -TypeName PSObject
        $REPORT | Add-Member -type NoteProperty -name Name -Value $vm.Name
        $REPORT | Add-Member -type NoteProperty -name VMHost -Value $vm.Host
        $REPORT | Add-Member -type NoteProperty -name Mode -Value $disk.Name
        $REPORT | Add-Member -type NoteProperty -name Type -Value "MultiWriter"
        $array += $REPORT
    }

}

#$array | out-gridview
#$array
#>