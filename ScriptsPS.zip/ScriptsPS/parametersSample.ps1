﻿#Connect-VIServer pxl1vmwvc105.dispositivos.bb.com.br
$nic_info = Get-VMHostNetworkAdapter -Physical -VMHost xvh022.df.intrabb.bb.com.br | Select VMHost, Name

 

$nic_collection = @()

 

foreach ($nic in $nic_info)

{

     $esxcli_cmd = Get-EsxCli -VMHost $nic.VMHost

     $collect_info = "" | Select VMHost, vmnic, Description

     $collect_info.VMHost = $nic.VMHost

     $collect_info.vmnic  = $nic.Name

     $collect_info.Description = ($esxcli.network.nic.list() | where {$_.Name -match $nic.Name}).Description

     $nic_collection += $collect_info

}

 

Write-Host $nic_collection



Function Copy-OneTwo {
    Param(
            [Parameter(Mandatory=$True,
                      Position=0)]
            [String]$Source,

            [Parameter(Mandatory=$True,
                      ParameterSetName="OneDestination")]
            [String]$Destination,

            [Parameter(Mandatory=$True,
                      ParameterSetName="TwoDestinations")]
            [String]$Destination1,
            
            [Parameter(Mandatory=$True,
                      ParameterSetName="TwoDestinations")]
            [String]$Destination2
         )

     switch ($PsCmdlet.ParameterSetName){
        "OneDestination"   { Copy-Item -Recurse $Source $Destination } 
        "TwoDestinations"  { Copy-Item -Recurse $Source $Destination1; Copy-Item $Source $Destination2 } 
     } 
}

$maxParallel = 2

 
 # vMotions - PARALLEL

$vms =  get-vmhost 'host1' | get-vm *

foreach($vm in $vms){

  Move-VM -VM (Get-VM -Name $vm.name) -destination 'host2' -RunAsync

  do

  {

    sleep 5

  } while((Get-Task -Status Running | where{$_.Name -eq 'RelocateVM_Task'}).Count -gt $maxParallel)

}


Get-VMHostNetworkAdapter -VMKernel -VMHost (get-cluster "myCluster1"|get-vmhost)  | ? {$_.PortgroupName -eq "nfs"} | select Name,VMhost,Mac,IP