﻿#
# Autor: Romes segat
# Data: 06/2020
# Script para verificar a compatibilidade de VMs em um Cluster
#

$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$ClusterName = Read-Host -prompt "Enter cluster name"
$hostsSource = Read-Host -Prompt 'Informe o HOSTs de Origem (separados por virgula): '
$strUser = Read-Host -Prompt 'Usuario: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "

Write-Host " "
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

#$vcenter,$hosts = $string.split(':')

Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1


$hosts_query = $hostsSource.Split(",")
$hosts = Get-VMHost -Location $ClusterName | Where {$_.ConnectionState -eq "Connected"} | Sort Name
#$destpath = [Environment]::GetFolderPath("Desktop")
$destpath = ".\data\"


$confirmNetTest = "y"
#while($confirmNetTest -ne "y") {
#	$confirmNetTest = Read-Host -prompt "Do you want to perform vMotion network test? This will migrate specified VM across the hosts ensuring the network connectivity (y/n)"
#	If ($confirmNetTest -eq "n") {break}
#}

#If ($confirmNetTest -eq "y") {
#	$TestVMName = Read-Host -prompt "Enter test VM name"
#	while ($TestVM -eq $null) {
#	$TestVM = Get-VM -Name $TestVMName -ErrorAction SilentlyContinue
#		If ($TestVM -eq $null) {$TestVMName = Read-Host "No such VM. Please provide VM name"}
#	}
#}

$IsTestVMAffected = $false
$viewSI = Get-View 'ServiceInstance'
$viewVmProvChecker = Get-View $viewSI.Content.VmProvisioningChecker

foreach ($strHostSource in $hosts_query) {
    $CSVObjects = @()
    $Results = @()
    $err = @()
    Write-Host " "
    Write-Host "Checando compatibilidade de migracao de VMs do HOST: " $strHostSource
    Write-Host " "

    $vms = Get-VMHost $strHostSource | Get-VM 
    ForEach ($VM in $vms) {
        $TestVM = $VM
        $vmHostsCompatErro = @()
        $vmHostsCompatOK = @()
		$vmCompatError = @()
        Write-Host "Checando VM : " $TestVM.Name
        for($i=0; $i -le $hosts.GetUpperBound(0); $i++){
	        $Results = $viewVmProvChecker.QueryVMotionCompatibilityEx($VM.Id, $hosts[$i].Id)
            $hostShort = $hosts[$i].Name.Split(".")
            $hostShort = $hostShort[0]
		    foreach ($Record in $Results) {
			    If ($Record.Error -ne $null) {
                    $vmHostsCompatErro += $hostShort
                    # Write-Host "Compatibilidade com erro para a VM : " $TestVM.Name " no HOST: " $hosts[$i].Name
                    
					$errVM = ""
				    foreach ($Error in $Record.Error) {
				        #$errVM = new-object PSObject
				        #$errVM | add-member -membertype NoteProperty -name "VM" -value $VM.Name #$Record.VM
				        #If ($Record.VM -eq $TestVM.Id) { $IsTestVMAffected = $true } 
				        #$errVM | add-member -membertype NoteProperty -name "Host" -value $hosts[$i].Name #$Record.Host
				        #$errVM | add-member -membertype NoteProperty -name "Error" -value "$($Error.LocalizedMessage)"
						$errVM = "$($errVM) $($hosts[$i].Name) $($Error.LocalizedMessage)"
						$vmCompatError += $errVM
				    }
                    					
			    }
                else {
                    $vmHostsCompatOK += $hostShort
                    #Write-Host "Compatibilidade OK para a VM : " $TestVM.Name " no HOST: " $hosts[$i].Name
                }
		    }
        }
   	    $CSVObject = new-object PSObject
	    $CSVObject | add-member -membertype NoteProperty -name "VM" -value $VM.Name
	    $CSVObject | add-member -membertype NoteProperty -name "Com Compat" -value "$($vmHostsCompatOK)"
	    $CSVObject | add-member -membertype NoteProperty -name "Sem Compat" -value "$($vmHostsCompatErro)"
		$CSVObject | add-member -membertype NoteProperty -name "Tipo erro" -value "$($vmCompatError)"
        $CSVObjects += $CSVObject
        #break

        #Write-Host "VM : " $TestVM.Name "," $vmHostsCompatOK "," $vmHostsCompatErro

        If ($confirmNetTest -eq "y") {
            <#
	        If (!$IsTestVMAffected) {
	            Write-Host "Testing vMotion network connectivity by migrating" $TestVM "across the hosts in " $ClusterName
	            $InitialVMHost = $TestVM.VMHost
		        for ($i=0; $i -le $hosts.GetUpperBound(0); $i++) {
				    If ($i -eq $hosts.GetUpperBound(0)) {
				        $DestHost = $hosts[0]
				    } 
                    else { 
                        $DestHost = $hosts[$i+1] 
                    }
			
			        Move-VM -VM $TestVM -Destination $DestHost -ErrorVariable +err 2>> $destpath\vMotionNetTest.txt | out-null
		        }	
		        If ($InitialVMHost -ne $hosts[0]) { 
                    Move-VM -VM $TestVM -Destination $InitialVMHost 
                }

		        $datetime = Get-Date
		        If ($err.count -eq 0) {
                    Write-Output "$datetime Network test completed successfully" >> $destpath\vMotionNetTest.txt
                }
	        } 
            else { 
                Write-Output "$datetime The specified test VM cannot be migrated. Please check vMotionTest.csv file for details" >> $destpath\vMotionNetTest.txt 
            }
            #>
        }

    }
    If ($CSVObjects.count -eq 0) {
	    $CSVObjectNoErr = new-object PSObject
	    $CSVObjectNoErr | add-member -membertype NoteProperty -name "Result" -value "No errors found"
	    $CSVObjectNoErr | Export-Csv -Path $destpath\vMotionTest.csv -NoTypeInformation
	    }
    else { 
        $CSVObjects | Export-Csv -Delimiter ";" -Path "$destpath\$($strHostSource)_vMotionCompatibility.csv" -NoTypeInformation 
    }
}



Disconnect-VIServer -Confirm:$False

