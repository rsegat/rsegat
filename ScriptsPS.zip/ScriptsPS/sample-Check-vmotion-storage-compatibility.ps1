﻿$vmName = 'MyVM'

$tgtDSName = 'MyDS'

 

$vm = Get-VM -Name $vmName

$ds = Get-Datastore -Name $tgtDSName

 

$si = Get-View ServiceInstance

$vmProvCheck = Get-View -Id $si.Content.VmProvisioningChecker

 

$spec = New-Object VMware.Vim.VirtualMachineRelocateSpec

$spec.Datastore = $ds.ExtensionData.MoRef

 

$result = $vmProvCheck.CheckRelocate($vm.ExtensionData.MoRef,$spec,$null)

$result | %{

    $_.Error | Select @{N='Message';E={$_.LocalizedMessage}}

}