﻿$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$myhosts = Read-Host -Prompt 'Informe o(s) HOST(s) separados por virgula: '
$strUser = Read-Host -Prompt 'Usuario: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "
Write-Host " "
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1

#$strVcenter = Read-Host -Prompt 'Informe o vCenter (sem o dominio): '
#$strUser = Read-Host -Prompt 'Usuario: '
#$strPassword = Read-Host 'Senha: ' -AsSecureString

#$strVcenter = "`$strVcenter`.dispositivos.bb.com.br"

#[CmdletBinding()]
<#
Param(
	[Parameter(Mandatory=$true)]
	[string]$strVcenter,

    [Parameter(Mandatory=$True)]
    [String]$strUser,

    [Parameter(Mandatory=$True)]
    [String]$strPassword

)
#>


#Connect-VIServer $strVcenter

$maxParallel = 125
$hosts_query = $myhosts.Split(",")

#$header = 'Name', 'State', 'Status', 'Provisioned Space', 'Used Space', 'Host CPU', 'Host Mem'
$header = 'vmName', 'vmState'

foreach ($strHost in $hosts_query) {

    $filepath = ".\data\$($strHost)_VmsInfo.csv"


    Write-Host "Devolvendo VMs para HOST " $strHost 

    Import-CSV $filepath -Header $header -Delimiter ";" | select -skip 1 | Foreach-Object{
        #Write-Host "Migrando VM: " $_.vmName 
        if ($_.vmName -ne "vmName") {
            Get-VM $_.vmName | Move-VM -Destination (Get-VMHost $strHost) -RunAsync
            #Move-VM -VM (Get-VM -Name $vm.name) -destination 'host2' -RunAsync

            while ((Get-Task -Status Running | where{$_.Name -eq 'RelocateVM_Task'}).Count -gt $maxParallel) {
                sleep 3
            }
        }
    }
 }

Disconnect-VIServer $strVcenter -Confirm:$False
Write-Host " "

exit
