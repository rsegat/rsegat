﻿<#
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$datastoreName
)
#>

$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$datastoreName = Read-Host -Prompt 'Informe o Datastore: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "



Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

Write-Host "Verificando Datastore.."

Get-Datastore -Name $datastoreName | Get-Vm |

Select @{N='Datastore';E={$datastoreName}},Name,PowerState |

Export-Csv -Path ".\data\$($datastoreName)_Vms.csv" -NoTypeInformation -UseCulture

#where{$_.PowerState -eq 'PoweredOff'}

Disconnect-VIServer $strVcenter -Confirm:$False
Write-Host " "
