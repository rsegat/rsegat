﻿Get-Module -Name VMware* -ListAvailable | Group-Object -Property Name | %{
        Write-host $_.Name
        #Uninstall-Module -Name $_.Name -Force -Confirm:$false -WhatIf
}