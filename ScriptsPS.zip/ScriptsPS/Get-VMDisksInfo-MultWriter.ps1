﻿[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$strClustername
)


#Create the array
$array = @()

$vms = Get-Cluster $strClustername | Get-VM | Sort-Object -Property Name
Write-host "Report Generation is in Progress..."

$VmInfo = ForEach ($VM in $vms) {
      ForEach ($HardDisk in ($VM | Get-HardDisk | Sort-Object -Property Name)) {
        "" | Select-Object -Property @{N="VM";E={$VM.Name}},
          #@{N="Datacenter";E={$Datacenter.name}},
          #@{N="Cluster";E={$Cluster.Name}},
          @{N="Hard Disk";E={$HardDisk.Name}},
          @{N="Hard Disk Type";E={$HardDisk.DiskType}},
          @{N="Datastore";E={$HardDisk.FileName.Split("]")[0].TrimStart("[")}},
          #@{N="VMConfigFile";E={$VM.ExtensionData.Config.Files.VmPathName}},
          @{N="VMDKpath";E={$HardDisk.FileName}}
          
          #$disks = Get-AdvancedSetting -Entity $vm | where{$_.Name -match "^scsi.*sharing"}
      }
    }
  

$VmInfo | Export-Csv -NoTypeInformation -UseCulture -Path ".\data\$($strClustername)-VM-Disk-Info.csv"


