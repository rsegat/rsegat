﻿$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$clusterName = Read-Host -Prompt 'Informe o Cluster de Hosts para remover DS: '
$myDS = Read-Host -Prompt 'Informe a(s) LUN(s) separadas por virgula: '
$myLunIDs = Read-Host -Prompt 'Informe a(s) LUN(s) ID separadas por virgula: '
$strUser = Read-Host -Prompt 'Usuario: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "

Write-Host " "
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

#$vcenter,$hosts = $string.split(':')

Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1

#import-module ".\DatastoreFunctions.ps1"

function Detach-Disk {
    param(
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$VMHost,
        [string]$CanonicalName    )
 
    $storSys = Get-View $VMHost.Extensiondata.ConfigManager.StorageSystem
    $lunUuid = (Get-ScsiLun -VmHost $VMHost | where {$_.CanonicalName -eq $CanonicalName}).ExtensionData.Uuid
 
    $storSys.DetachScsiLun($lunUuid)
}

Function Detach-Datastore {
	[CmdletBinding()]
	Param (
		[Parameter(ValueFromPipeline=$true)]
		$Datastore
	)
	Process {
		if (-not $Datastore) {
			Write-Host "No Datastore defined as input"
			Exit
		}
		Foreach ($ds in $Datastore) {
			$hostviewDSDiskName = $ds.ExtensionData.Info.vmfs.extent[0].Diskname
			if ($ds.ExtensionData.Host) {
				$attachedHosts = $ds.ExtensionData.Host
				Foreach ($VMHost in $attachedHosts) {
					$hostview = Get-View $VMHost.Key
					$StorageSys = Get-View $HostView.ConfigManager.StorageSystem
					$devices = $StorageSys.StorageDeviceInfo.ScsiLun
					Foreach ($device in $devices) {
						if ($device.canonicalName -eq $hostviewDSDiskName) {
							$LunUUID = $Device.Uuid
							Write-Host "Detaching LUN $($Device.CanonicalName) from host $($hostview.Name)..."
							$StorageSys.DetachScsiLun($LunUUID);
						}
					}
				}
			}
		}
	}
}

Function Unmount-Datastore {
	[CmdletBinding()]
	Param (
		[Parameter(ValueFromPipeline=$true)]
		$Datastore
	)
	Process {
		if (-not $Datastore) {
			Write-Host "No Datastore defined as input"
			Exit
		}
		Foreach ($ds in $Datastore) {
			$hostviewDSDiskName = $ds.ExtensionData.Info.vmfs.extent[0].Diskname
			if ($ds.ExtensionData.Host) {
				$attachedHosts = $ds.ExtensionData.Host
				Foreach ($VMHost in $attachedHosts) {
					$hostview = Get-View $VMHost.Key
					$StorageSys = Get-View $HostView.ConfigManager.StorageSystem
					Write-Host "Unmounting VMFS Datastore $($DS.Name) from host $($hostview.Name)..."
					$StorageSys.UnmountVmfsVolume($DS.ExtensionData.Info.vmfs.uuid);
				}
			}
		}
	}
}


if ($myDS) { 
    $datastores = $myDS.Split(",")
    Foreach($lun in $datastores) {
        Write-Host "Removendo LUN: " $lun -ForegroundColor "Green"
	    Get-Datastore $lun | Unmount-Datastore
	    Get-Datastore $lun | Detach-Datastore
        #Get-Datastore  $lun | Select -ExpandProperty ExtensionData #Select Name, @{N='LUN';E={$_.ExtensionData.Info.Vmfs.Extent.DiskName -join ' | '}}
        #$canonicalName = Get-Datastore $lun | Select {$_.Extensiondata.Info.Vmfs.Extent[0].DiskName} #$ds.ExtensionData.Info.Vmfs.Extent[0].DiskName
        #$canonicalName 
    }

}
else {
    $LunIDs = $myLunIDs.Split(",")
    $ClusterHosts = Get-Cluster $clusterName | Get-VMHost
 
    Foreach($VMHost in $ClusterHosts) {
        Foreach($LUNid in $LunIDs) {
            Write-Host "Detaching" $LUNid "from" $VMHost -ForegroundColor "Yellow"
            Detach-Disk -VMHost $VMHost -CanonicalName $LUNid
        }
    }
}


Disconnect-VIServer $strVcenter -Confirm:$False
Write-Host " "

exit















#$datastores = get-content ".\data\LUNS_desaloca.csv"

#For para buscar os datastore e fazer o Detach ou Unmount
foreach($lun in $datastores) {
    Write-Host "Removendo LUN:" $lun
    if ($myDS) { 
	    #Get-Datastore $lun | Unmount-Datastore
	    #Get-Datastore $lun | Detach-Datastore
        #Get-Datastore  $lun | Select -ExpandProperty ExtensionData #Select Name, @{N='LUN';E={$_.ExtensionData.Info.Vmfs.Extent.DiskName -join ' | '}}
        $canonicalName = Get-Datastore $lun | Select {$_.Extensiondata.Info.Vmfs.Extent[0].DiskName} #$ds.ExtensionData.Info.Vmfs.Extent[0].DiskName
        $canonicalName 
    }
    else {
	    #Get-Datastore -Id $lun | Unmount-Datastore
	    #Get-Datastore -Id $lun | Detach-Datastore
        #Get-Cluster -Name $clusterName | Get-VMHost | Get-Datastore | Select Name,@{N='CanonicalName';E={$_.Extensiondata.Info.Vmfs.Extent[0].DiskName}} #| Where-Object {$_.ExtensionData.Info.Vmfs.Extent[0].DiskName -eq $lun} | Select Name,@{N='CanonicalName';E={$_.Extensiondata.Info.Vmfs.Extent[0].DiskName}}
        Get-Cluster -Name $clusterName | Get-VMHost | Get-ScsiLun -CanonicalName $lun | Detach-Datastore

        #$canonicalName = $lun #$ds.ExtensionData.Info.Vmfs.Extent[0].DiskName
        #$storSys = Get-View $esx.Extensiondata.ConfigManager.StorageSystem
        #$device = $storsys.StorageDeviceInfo.ScsiLun | where {$_.CanonicalName -eq $canonicalName}
        #if($device.OperationalState[0] -eq 'ok'){
            # unmount disk
        #    $StorSys.UnmountVmfsVolume($ds.ExtensionData.Info.Vmfs.Uuid)
        #}
        # Detach disk
        #$storSys.DetachScsiLun($device.Uuid)
    }
}



$ClusterHosts = Get-Cluster $Cluster | Get-VMHost
 
Foreach($VMHost in $ClusterHosts)
{
    Foreach($LUNid in $LunIDs)
    {
        Write-Host "Detaching" $LUNid "from" $VMHost -ForegroundColor "Yellow"
        Detach-Disk -VMHost $VMHost -CanonicalName $LUNid
    }
}