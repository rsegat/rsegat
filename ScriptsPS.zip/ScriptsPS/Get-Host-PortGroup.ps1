﻿#
# Autor: Romes segat
# Data: 05/2020
#
#
#Clear
Write-Host " "
Write-Host " "
Write-Host " "
Write-Host " "
Write-Host " "
Write-Host "**************************************************************************************************** "
Write-Host " "
Write-Host "Script para copiar os PortGroups do Standard Switch de um Host para Outro Host"
Write-Host " "
Write-Host "**************************************************************************************************** "
Write-Host " "
$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$mySourcehost = Read-Host -Prompt 'Informe o HOST Origem: '
$myTargethost = Read-Host -Prompt 'Informe o HOST Destino: '
$strUser = Read-Host -Prompt 'Usuario: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "
Write-Host " "
Write-Host "**************************************************************************************************** "
#
#$strPassword = Read-Host 'Senha: ' -AsSecureString

Write-Host " "
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1
Import-Module VMware.VimAutomation.Vds 

#$myVMHost = Get-VMHost -Name $myhosts
#$strsovirprgrp = Get-VirtualPortGroup -Name "vSwitch0" -VMHost $myVmHost

#$strvswitchonhost02 = Get-VirtualSwitch -Name vSwitch0 -VMHost $myhosts  # Host 01 have virtual switch named vswitch0, we have to create same switch in host 02. Its already created and $strvSwitchonhost02 variable store that details
#$strsovirprgrp = Get-VirtualPortGroup -VMHost $myhosts -Name vSwitch0   # Store all the virtual port details in a $strsovirprgrp array

$strVswSource = Get-VirtualSwitch -VMHost $mySourcehost -Name vSwitch0 -Standard
$strsovirprgrp = Get-VirtualPortGroup -VirtualSwitch $strVswSource -Standard
$strVswTarget = Get-VirtualSwitch -Name vSwitch0 -VMHost $myTargethost -Standard  >$null 2>&1
if ($?) { 
    Write-Host "vSwitch0 Encontrado.. " 
    $strVswTarget
}
else{
    Write-Host "Nao econtrado o vSwitch0. Vou criar..." 
    $strVswTarget = New-VirtualSwitch -Name vSwitch0 -VMHost $myTargethost
}
Write-Host " "


$intcount = $strsovirprgrp.count 

For ($a=0 ; $a -le $intcount-1 ; $a++) {
    $strPGname = $strsovirprgrp[$a].name
    $intvLanID = $strsovirprgrp[$a].VLANID

    Write-Host "Adicionando PortGroup: " $strPGname ", VlanID: " $intvLanID " ao HOST: " $myTargethost
    New-VirtualPortGroup -VirtualSwitch $strVswTarget -Name $strPGname -VLanId $intvLanID

    #New-virtualporggroup -virtualSwitch $strvswitchonhost02 -name $strname -VLANId  $intvlan # create virtual port group/s on second host
}

Disconnect-VIServer $strVcenter -Confirm:$False
Write-Host " "
Write-Host " "
Write-Host " "
Write-Host " "
