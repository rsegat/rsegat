﻿PS C:\Users\romes\OneDrive\Documentos\vmWare\ScriptsPS> Get-VMHostNetworkAdapter -VMKernel -VMHost xvh046.df.intrabb.bb.com.br  | select DeviceName, Mac, DhcpEnabled, IP, SubnetMask


DeviceName  : vmk0
Mac         : 9c:dc:71:45:9e:80
DhcpEnabled : False
IP          : 10.8.3.31
SubnetMask  : 255.255.255.0

DeviceName  : vmk1
Mac         : 00:50:56:6f:e3:d8
DhcpEnabled : False
IP          : 192.168.0.31
SubnetMask  : 255.255.255.0



PS C:\Users\romes\OneDrive\Documentos\vmWare\ScriptsPS> Get-VMHostNetworkAdapter -VirtualSwitch Web-01  -VMHost xvh046.df.intrabb.bb.com.br

Name       Mac               DhcpEnabled IP              SubnetMask      DeviceName
----       ---               ----------- --              ----------      ----------
vmnic0     e0:07:1b:79:a3:d0 False                                           vmnic0
vmnic3     9c:dc:71:45:9e:80 False                                           vmnic3
vmk0       9c:dc:71:45:9e:80 False       10.8.3.31       255.255.255.0         vmk0
vmk1       00:50:56:6f:e3:d8 False       192.168.0.31    255.255.255.0         vmk1


$esxcli = Get-Esxcli -vmhost Hostname -V2
$esxcli.network.nic.list.invoke() | where {$_.linkstatus -eq "up"} 
