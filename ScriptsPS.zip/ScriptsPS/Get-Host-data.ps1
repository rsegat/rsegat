﻿#hosts_query = "xvb051.dispositivos.bb.com.br,xvb053.dispositivos.bb.com.br,xvb057.dispositivos.bb.com.br"

$strVcenter = Read-Host -Prompt 'Informe o vCenter: '
$myhosts = Read-Host -Prompt 'Informe o(s) HOST(s) separados por virgula: '
$strUser = Read-Host -Prompt 'Usuario: '
$credentials = Get-Credential -UserName $strUser -Message "Sua senha: "
#
#$strPassword = Read-Host 'Senha: ' -AsSecureString

Write-Host " "
Write-Host "Conectando ao vCenter: " $strVcenter
Write-Host " "

#$vcenter,$hosts = $string.split(':')

Connect-VIServer -Server $strVcenter -Credential $credentials >$null 2>&1
Import-Module VMware.VimAutomation.Vds 

#Connect-VIServer -Server $strVcenter -User $strUser -Password $strPassword
#Connect-VIServer $strVcenter -User $strUser -Password $strPassword
#Connect-VIServer $strVcenter

$hosts_query = $myhosts.Split(",")

foreach ($strHost in $hosts_query) {
    Write-Host "Verificando VMs do Host: " $strHost
    $vms = Get-VMHost $strHost | Get-VM | Sort-Object -Property Name
    $vmsInfo = ForEach ($VM in $vms) {
        "" | Select-Object -Property @{N="vmName";E={$VM.Name}},
        @{N="vmState";E={$VM.PowerState}}
        #Write-Host $VM.Name,$VM.PowerState
    }
    $vmsInfo | Export-Csv -NoTypeInformation -UseCulture -Path ".\data\$($strHost)_VmsInfo.csv"
}

Write-Host " "
foreach ($strHost in $hosts_query) {
    Write-Host "Verificando REDE do Host: " $strHost
    $collection = @() 
    $Esxihost = Get-VMHost $strHost
    #foreach ($Esxihost in $Esxihosts) {
        $Esxcli = Get-EsxCli -VMHost $Esxihost  
        $Esxihostview = Get-VMHost $EsxiHost | get-view  
        $NetworkSystem = $Esxihostview.Configmanager.Networksystem  
        $Networkview = Get-View $NetworkSystem  
       
        # $DvSwitchInfo = Get-VDSwitch -VMHost $Esxihost  
        # if ($DvSwitchInfo -ne $null) {  
        #   $DvSwitchHost = $DvSwitchInfo.ExtensionData.Config.Host  
        #   $DvSwitchHostView = Get-View $DvSwitchHost.config.host  
        #   $VMhostnic = $DvSwitchHostView.config.network.pnic  
        #   $DVNic = $DvSwitchHost.config.backing.PnicSpec.PnicDevice  
        # }  
     
        $VMnics = $Esxihost | get-vmhostnetworkadapter -Physical #| Where-object {$_.Link -eq "Up"}   #$_.NetworkInfo.Pnic  | where-object 
        Foreach ($VMnic in $VMnics){  
            $realInfo = $Networkview.QueryNetworkHint($VMnic)  
            $pNics = $esxcli.network.nic.list() | where-object {$vmnic.name -eq $_.name} | Select-Object Description, Link           
            $Description = $esxcli.network.nic.list()  
            $CDPextended = $realInfo.connectedswitchport  
    #         if ($vmnic.Name -eq $DVNic) {  
    #             
    #           $vSwitch = $DVswitchInfo | where-object {$vmnic.Name -eq $DVNic} | select-object -ExpandProperty Name  
    #         }  
    #         else {  
                $vSwitchname = $Esxihost | Get-VirtualSwitch | Where-object {$_.nic -eq $VMnic.DeviceName}  
                $vSwitch = $vSwitchname.name  
    #         }  
            if ($pNics.Link -eq "Up") {
                $CDPdetails = New-Object PSObject  
                #$CDPdetails | Add-Member -Name EsxName -Value $esxihost.Name -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name VMNic -Value $VMnic -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name vSwitch -Value $vSwitch -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name Link -Value $pNics.Link -MemberType NoteProperty   
                $CDPdetails | Add-Member -Name PortNo -Value $CDPextended.PortId -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name Device-ID -Value $CDPextended.devID -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name Switch-IP -Value $CDPextended.Address -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name MacAddress -Value $vmnic.Mac -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name SpeedMB -Value $vmnic.ExtensionData.LinkSpeed.SpeedMB -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name Duplex -Value $vmnic.ExtensionData.LinkSpeed.Duplex -MemberType NoteProperty  
                $CDPdetails | Add-Member -Name Pnic-Vendor -Value $pNics.Description -MemberType NoteProperty  
                #$CDPdetails | Add-Member -Name Pnic-drivers -Value $vmnic.ExtensionData.Driver -MemberType NoteProperty  
                #$CDPdetails | Add-Member -Name PCI-Slot -Value $vmnic.ExtensionData.Pci -MemberType NoteProperty  
                $collection += $CDPdetails  
            }
        }  
        $collection | Format-Table -AutoSize
        #$collection | Sort-Object vmnic | Export-Csv -Path ".\data\$($strHost)_vSwitchsInfo.csv" -NoTypeInformation -UseCulture

        $collectionvmk = @() 
        $Esxihost = Get-VMHost $strHost
        Write-Host "Verificando vmKernel do Host: " $strHost
        $vmkernel = Get-VMHostNetworkAdapter -VMKernel -VMHost $strHost  | select DeviceName, Mac, DhcpEnabled, IP, SubnetMask, Name, PortGroupName, vMotionEnabled, DefaultGateway
        Foreach ($vmk in $vmkernel){  
            $vmkDetails = New-Object PSObject  
            $vmkDetails | Add-Member -Name DeviceName -Value $vmk.DeviceName -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name Mac -Value $vmk.Mac -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name DhcpEnabled -Value $vmk.DhcpEnabled -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name IP -Value $vmk.IP -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name Name -Value $vmk.Name -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name PortGroupName -Value $vmk.PortGroupName -MemberType NoteProperty  
            $vmkDetails | Add-Member -Name DefaultGateway -Value $Esxihost.ExtensionData.Config.Network.IpRouteConfig.DefaultGateway -MemberType NoteProperty  
            $collectionvmk += $vmkDetails
        }
        $collectionvmk | Format-Table -AutoSize
        #$collectionvmk | Export-Csv -Path ".\data\$($strHost)_vKernelInfo.csv" -NoTypeInformation -UseCulture

   #}

}

Write-Host " "

<#

foreach($strHost in $hosts_query){
    $array = @()

    $esx = Get-VMHost -Name $strHost
    #Get-VMHostNetworkAdapter -VMHost $strHost | select VMhost, Name, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex, BitRatePerSec | Export-Csv -Path ".\data\$($strHost)_vSwitchsInfo.csv" -NoTypeInformation -UseCulture

    $networkAdapter = Get-VMHostNetworkAdapter -VMHost $strHost | select Name, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex
    $REPORT = New-Object -TypeName PSObject
    $REPORT | Add-Member -type NoteProperty -name Name -Value $networkAdapter.Name
    $REPORT | Add-Member -type NoteProperty -name IP -Value $networkAdapter.IP
    $REPORT | Add-Member -type NoteProperty -name SubnetMask -Value $networkAdapter.SubnetMask
    $REPORT | Add-Member -type NoteProperty -name Mac -Value $networkAdapter.Mac
    $REPORT | Add-Member -type NoteProperty -name PortGroupName -Value $networkAdapter.PortGroupName
    $REPORT | Add-Member -type NoteProperty -name vMotionEnabled -Value $networkAdapter.vMotionEnabled
    $REPORT | Add-Member -type NoteProperty -name mtu -Value $networkAdapter.mtu
    $REPORT | Add-Member -type NoteProperty -name FullDuplex -Value $networkAdapter.FullDuplex
    $array += $REPORT

    foreach($vsw in (Get-VirtualSwitch -VMHost $esx)){
        $myVDSwitch = Get-VDSwitch -Name $vsw

        $networkAdapter = Get-VMHostNetworkAdapter -VirtualSwitch $myVDSwitch -VMKernel | select Name, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex
        $REPORT = New-Object -TypeName PSObject
        $REPORT | Add-Member -type NoteProperty -name Name -Value $networkAdapter.Name
        $REPORT | Add-Member -type NoteProperty -name IP -Value $networkAdapter.IP
        $REPORT | Add-Member -type NoteProperty -name SubnetMask -Value $networkAdapter.SubnetMask
        $REPORT | Add-Member -type NoteProperty -name Mac -Value $networkAdapter.Mac
        $REPORT | Add-Member -type NoteProperty -name PortGroupName -Value $networkAdapter.PortGroupName
        $REPORT | Add-Member -type NoteProperty -name vMotionEnabled -Value $networkAdapter.vMotionEnabled
        $REPORT | Add-Member -type NoteProperty -name mtu -Value $networkAdapter.mtu
        $REPORT | Add-Member -type NoteProperty -name FullDuplex -Value $networkAdapter.FullDuplex
        $array += $REPORT
    }

    $array | Export-Csv -Path ".\data\$($strHost)_vSwitchsInfo.csv" -NoTypeInformation -UseCulture
}
#>

<#
foreach($strHost in $hosts_query){
    $vNicTab = @{}
    $esx = Get-VMHost -Name $strHost

    #$esx.ExtensionData.Config.Network.Vnic | %{
    #    $vNicTab.Add($_.Portgroup,$_)
    #}

    foreach($vsw in (Get-VirtualSwitch -VMHost $esx)){
        $hostSwitch = foreach($pg in (Get-VirtualPortGroup -VirtualSwitch $vsw)){
            Select -InputObject $pg -Property @{N="ESX";E={$esx.name}},
                @{N="vSwitch";E={$vsw.Name}},
                @{N="Active NIC";E={[string]::Join(',',$vsw.ExtensionData.Spec.Policy.NicTeaming.NicOrder.ActiveNic)}},
                @{N="Standby NIC";E={[string]::Join(',',$vsw.ExtensionData.Spec.Policy.NicTeaming.NicOrder.StandbyNic)}},
                @{N="Portgroup";E={$pg.Name}},
                @{N="VLAN";E={$pg.VLanId}},
                @{N="Device";E={if($vNicTab.ContainsKey($pg.Name)){$vNicTab[$pg.Name].Device}}},
                @{N="IP";E={if($vNicTab.ContainsKey($pg.Name)){$vNicTab[$pg.Name].Spec.Ip.IpAddress}}}
        }
        $hostSwitch | Export-Csv -Path ".\data\$($strHost)_vSwitchsInfo.csv" -NoTypeInformation -UseCulture
    }
}
#>


Disconnect-VIServer $strVcenter -Confirm:$False
Write-Host " "

exit
#$strVcenter = "`$strVcenter`.dispositivos.bb.com.br"
