[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true)]
	[string]$strVmName,
	[Parameter()]
	[string]$strType
)
if ($strType -eq "raw"){
	$objDisks = Get-HardDisk $strVmName | ?  {$_.DiskType -eq "RawPhysical"}
} else {
	$objDisks = Get-HardDisk $strVmName
}
$objVmView = Get-View -ViewType VirtualMachine -Filter @{"Name" = $strVmName}

$colDisks = @()
ForEach ($objDisk in $objDisks){

	$VmName = $objDisk.Parent
	$HardDisk = $objDisk.ExtensionData.DeviceInfo.Label
	$CapacityGB = $objDisk.CapacityGB
	$Filename = $objDisk.Filename
	$DeviceName = $objDisk.DeviceName
	$StorageFormat = $objDisk.StorageFormat
	If ($objDisk.DiskType -eq "RawPhysical") {
		$ScsiCanonicalName = ($objDisk.ScsiCanonicalName).split(".")[1]
	}
    $objDisks = $null
    $objDisks = New-Object System.Object
    $objDisks | Add-Member -type NoteProperty �name VmName �value $VmName
	$objDisks | Add-Member -type NoteProperty �name HardDisk �value $HardDisk
	$objDisks | Add-Member -type NoteProperty �name CapacityGB �value $CapacityGB
	$objDisks | Add-Member -type NoteProperty �name Filename �value $Filename
	
	#$objDisks | Add-Member -type NoteProperty �name StorageFormat �value $StorageFormat
	
	#$objDisks | Add-Member -type NoteProperty �name DeviceName �value $DeviceName
	#$objDisks | Add-Member -type NoteProperty �name ScsiCanonicalName �value $ScsiCanonicalName
	
	ForEach ($VirtualSCSIController in ($objVmView.Config.Hardware.Device | where {$_.DeviceInfo.Label -match "SCSI Controller"})) {
		ForEach ($VirtualDiskDevice in ($objVmView.Config.Hardware.Device | where {$_.ControllerKey -eq $VirtualSCSIController.Key})) {
			If ($VirtualDiskDevice.DeviceInfo.Label -eq "$HardDisk") {
				$SCSI_Controller = "SCSI controller " + $($VirtualSCSIController.BusNumber)
				$SCSI_UnitNumber = $VirtualDiskDevice.UnitNumber
			}
		}
	}
	
	#$objDisks | Add-Member -type NoteProperty �name SCSI_Controller �value $SCSI_Controller
	#$objDisks | Add-Member -type NoteProperty �name SCSI_UnitNumber �value $SCSI_UnitNumber
    $colDisks += $objDisks
}
$colDisks
